<?php
defined('BASEPATH') OR exit('No direct script access allowed');

 class StudentControlar extends CI_Controller{
   
    public function index(){
        $this->load->model('StudenModel');

        $student=$this->StudenModel->std_data();
        echo "the student name is $student";

    }
 }



