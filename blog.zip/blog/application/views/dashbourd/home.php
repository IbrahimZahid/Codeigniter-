
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
  $this->extend('layout/dashbourd-layout');
  $this->section('content');  

  $this->endSection();  

?>