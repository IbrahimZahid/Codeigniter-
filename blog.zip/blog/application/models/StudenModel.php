<?php
class StudenModel extends CI_Model{
  public function std_data()
  {
    return 'Ebrahim Zahid';
  }
  


  public function demo()
  {
    $titlee =  'Helow i am zahid from taking to the student model';
    return $titlee;
  }

}




?>