<?php
defined('BASEPATH') OR exit('No direct script access allowed');

 class UserControlar extends CI_Controller{
    public function userIndex()
    {
          return $this->load->view('dashbourd/home');
    }

 }

 ?>