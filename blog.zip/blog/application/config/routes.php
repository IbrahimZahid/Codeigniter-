<?php
defined('BASEPATH') OR exit('No direct script access allowed');




$route['default_controller'] = 'welcome';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

//$route['default_controller'] = 'StudentControlar';

 //$route['home']='PageControlar/index';
 $route['about'] = 'Welcome/demo';

 $route['student'] = 'StudentControlar/index';

 //$route['home']='PageControlar/demoo';
 // this below is only returnig any data
 //$route['test/(:any)'] = 'PageControlar/blog/$1';


 //this below is returnig only number
 $route['test/(:num)'] = 'PageControlar/blog/$1';


 //-------------------------------------------------------------
 // employee routes to

 $route['employee']='FrontEnd/EmployeeControlar/index';

 $route['employee/add']='FrontEnd/EmployeeControlar/create';

 $route['employee/store']='FrontEnd/EmployeeControlar/store';
 $route['employee/edit(:any)'] = 'FrontEnd/EmployeeControlar/edit/$1';

 $route['employee/update(:any)'] = 'FrontEnd/EmployeeControlar/update/$1';

 $route['employee/delete(:any)'] = 'FrontEnd/EmployeeControlar/delete/$1';

 $route['employee/comfirDelete(:any)']  = 'FrontEnd/EmployeeControlar/delete/$1';
//----------------------------------------------------authentication admin--------

$route['home']='UserControlar/userIndex'; 


 
 

 