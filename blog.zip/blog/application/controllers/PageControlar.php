<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PageControlar extends CI_Controller{

    public function index(){
        echo " I am index method Controlar page";
    }
    
    public function demo(){
        echo 'this is my first vesion';
    }

    function blog($var = ' ') {

        echo "this is id of BLog $var";
        $this->load->view('Blogviev');
       }


        function demoo() 
        {
        // $data['title']= 'hellow i am Zahid from id of is islamic departments';
         $this->load->model('StudenModel');
         $var = $this -> StudenModel->demo();
         $data['title']=$var;
         $data['bodi']= 'zahid jan is best in computer science';
            $this ->load->view('SideView', $data);
        }
    
}